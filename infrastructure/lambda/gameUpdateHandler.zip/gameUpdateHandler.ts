import { Kafka } from 'kafkajs';
import axios from 'axios';

const kafka = new Kafka({
  clientId: 'nba-live-producer',
  brokers: (process.env.KAFKA_BROKERS || '').split(','),
  ssl: true,
});

const producer = kafka.producer();

interface GameData {
  gameId: string;
  homeTeam: {
    teamId: string;
    score: number;
    name: string;
  };
  awayTeam: {
    teamId: string;
    score: number;
    name: string;
  };
  status: string;
  period: number;
  clock: string;
  lastUpdated: number;
}

async function fetchLiveGameData(): Promise<GameData[]> {
  const response = await axios.get('https://api.nba.com/v1/live/games');
  return response.data.games;
}

export async function handleGameUpdate(event: any): Promise<any> {
  try {
    await producer.connect();
    const games = await fetchLiveGameData();
    
    // Send each game update to Kafka
    await Promise.all(games.map(async (game) => {
      await producer.send({
        topic: 'nba-live-updates',
        messages: [
          { 
            key: game.gameId,
            value: JSON.stringify(game)
          },
        ],
      });
    }));

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Games published to Kafka', count: games.length })
    };
  } catch (error) {
    console.error('Error publishing games:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to publish games' })
    };
  } finally {
    await producer.disconnect();
  }
} 